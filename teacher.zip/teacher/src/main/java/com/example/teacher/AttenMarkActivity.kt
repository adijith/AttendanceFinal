package com.example.teacher

import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.ProgressBar
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.teacher.databinding.ActivityAddStudentBinding
import com.example.teacher.databinding.ActivityAttenMarkBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import java.util.Calendar

class AttenMarkActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAttenMarkBinding
    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var progressBar: ProgressBar

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAttenMarkBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firebaseAuth = FirebaseAuth.getInstance()

        val currentDate = getCurrentDate()
        binding.dateText.text = currentDate

        val teacherId = firebaseAuth.currentUser!!.uid
        fetchSubjectInfos(teacherId) { subjectInfos ->
            populateSpinner(subjectInfos)

            binding.showStudentsButton.setOnClickListener {
                val selectedSubject = binding.subjectSpinner.selectedItem as String
                val yearNode = selectedSubject.substringAfterLast('(').substringBeforeLast(')')
                fetchStudents(yearNode) { students ->
                    // Clear existing rows
                    binding.studentsTableLayout.removeAllViews()

                    // Iterate through students and add rows dynamically
                    students.forEach { student ->
                        val row = TableRow(this@AttenMarkActivity)
                        val layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT)
                        row.layoutParams = layoutParams

                        val studentNameTextView = TextView(this@AttenMarkActivity)
                        studentNameTextView.text = student.second
                        studentNameTextView.setPadding(8, 8, 8, 8)
                        row.addView(studentNameTextView)

                        val statusTextView = TextView(this@AttenMarkActivity)
                        statusTextView.text = "Absent" // Default status
                        statusTextView.setPadding(8, 8, 8, 8)
                        row.addView(statusTextView)

                        // Add the row to the table layout
                        binding.studentsTableLayout.addView(row)
                    }
                }
            }

        }
    }

    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1  // Month is 0-indexed
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        return String.format("%02d/%02d/%d", day, month, year)  // Format the date (MM/DD/YYYY)
    }

    private fun fetchSubjectInfos(teacherId: String, callback: (List<SubjectInfo>) -> Unit) {
        val database = FirebaseDatabase.getInstance()
        val subjectsRef = database.getReference("Teachers").child(teacherId).child("subjects")

        subjectsRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val subjectInfos = mutableListOf<SubjectInfo>()
                for (subjectSnapshot in snapshot.children) {
                    val subjectId = subjectSnapshot.key
                    subjectId?.let { id ->
                        val yearNode = id.split("-")[0] + id.split("-")[1]
                        fetchSubjectName(yearNode, id) { name ->
                            val subjectInfo = SubjectInfo(id, name, yearNode)
                            subjectInfos.add(subjectInfo)
                            if (subjectInfos.size == snapshot.childrenCount.toInt()) {
                                callback(subjectInfos)
                            }
                        }
                    }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle possible errors
                callback(emptyList())
            }
        })
    }

    private fun fetchSubjectName(yearNode: String, subjectId: String, callback: (String) -> Unit) {
        val database = FirebaseDatabase.getInstance()
        val subjectNameRef = database.getReference("Subjects").child(yearNode).child(subjectId).child("subjectName")

        subjectNameRef.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val subjectName = snapshot.getValue(String::class.java) ?: "Unknown"
                callback(subjectName)
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle database error
                Log.e("AttenMarkActivity", "fetchSubjectName:onCancelled", error.toException())
                callback("Unknown")
            }
        })
    }

    private fun populateSpinner(subjectInfos: List<SubjectInfo>) {
        val subjectInfoStrings = subjectInfos.map { "${it.subjectId} - ${it.subjectName} (${it.yearNode})" }
        val adapter = ArrayAdapter(this@AttenMarkActivity, android.R.layout.simple_spinner_item, subjectInfoStrings)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.subjectSpinner.adapter = adapter
    }
}
private fun fetchStudents(yearNode: String, callback: (List<Pair<String, String>>) -> Unit) {
    val database = FirebaseDatabase.getInstance()
    val studentsRef = database.getReference("attendance").child(yearNode)

    studentsRef.addListenerForSingleValueEvent(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val students = mutableListOf<Pair<String, String>>()
            for (studentSnapshot in snapshot.children) {
                val studentId = studentSnapshot.key
                studentId?.let { id ->
                    fetchStudentName(id) { name ->
                        val studentPair = Pair(id, name)
                        students.add(studentPair)
                        if (students.size == snapshot.childrenCount.toInt()) {
                            callback(students)
                        }
                    }
                }
            }
        }

        override fun onCancelled(error: DatabaseError) {
            // Handle database error
            Log.e("AttenMarkActivity", "fetchStudents:onCancelled", error.toException())
            callback(emptyList())
        }
    })
}

private fun fetchStudentName(studentId: String, callback: (String) -> Unit) {
    val database = FirebaseDatabase.getInstance()
    val studentNameRef = database.getReference("Students").child(studentId).child("name")

    studentNameRef.addListenerForSingleValueEvent(object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val studentName = snapshot.getValue(String::class.java) ?: "Unknown"
            callback(studentName)
        }

        override fun onCancelled(error: DatabaseError) {
            // Handle database error
            Log.e("AttenMarkActivity", "fetchStudentName:onCancelled", error.toException())
            callback("Unknown")
        }
    })
}

data class SubjectInfo(
    val subjectId: String,
    val subjectName: String,
    val yearNode: String
)
